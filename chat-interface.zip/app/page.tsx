import { Chat } from "@/components/chat"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-4 md:p-24">
      <div className="w-full max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-center">Chat Interface</h1>
        <Chat />
      </div>
    </main>
  )
}
