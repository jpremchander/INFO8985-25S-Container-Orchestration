"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"

type MessageType = {
  id: string
  content: string
  isUser: boolean
  isHtml: boolean
}

export function Chat() {
  const [messages, setMessages] = useState<MessageType[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    // Add user message
    const userMessage: MessageType = {
      id: Date.now().toString(),
      content: input,
      isUser: true,
      isHtml: false,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // Simulate API call with timeout
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Example response - in a real app, this would come from your API
      const isHtml = Math.random() > 0.5 // Randomly decide if response is HTML or plain text
      const responseContent = isHtml
        ? `<div style="color: blue; font-weight: bold;">This is an HTML response</div>
           <ul>
             <li>Item 1</li>
             <li>Item 2</li>
             <li>Item 3</li>
           </ul>`
        : `This is a plain text response to: "${input}"`

      const botMessage: MessageType = {
        id: (Date.now() + 1).toString(),
        content: responseContent,
        isUser: false,
        isHtml: isHtml,
      }

      setMessages((prev) => [...prev, botMessage])
    } catch (error) {
      console.error("Error sending message:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-[70vh] border rounded-lg overflow-hidden bg-background">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            Start a conversation by typing a message below
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "max-w-[80%] rounded-lg p-3",
                message.isUser ? "bg-primary text-primary-foreground ml-auto" : "bg-muted mr-auto",
              )}
            >
              {message.isHtml ? (
                <div
                  dangerouslySetInnerHTML={{ __html: message.content }}
                  className="prose prose-sm dark:prose-invert max-w-none"
                />
              ) : (
                <p className="whitespace-pre-wrap">{message.content}</p>
              )}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="border-t p-4 flex flex-col space-y-2">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message here..."
          className="min-h-[80px] resize-none"
          disabled={isLoading}
        />
        <Button type="submit" className="ml-auto" disabled={isLoading || !input.trim()}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending...
            </>
          ) : (
            "Send"
          )}
        </Button>
      </form>
    </div>
  )
}
